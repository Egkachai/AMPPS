<?php
$conf['dblayer'] = 'mysqli';
$conf['db_base'] = '[[softdb]]';
$conf['db_user'] = '[[softdbuser]]';
$conf['db_password'] = '[[softdbpass]]';
$conf['db_host'] = '[[softdbhost]]';

$prefixeTable = '[[dbprefix]]';

define('PHPWG_INSTALLED', true);
define('PWG_CHARSET', 'utf-8');
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

?>