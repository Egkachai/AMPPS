<?php
$_conf['jrCore_db_host'] = '[[softdbhost]]';
$_conf['jrCore_db_port'] = '3306';
$_conf['jrCore_db_name'] = '[[softdb]]';
$_conf['jrCore_db_user'] = '[[softdbuser]]';
$_conf['jrCore_db_pass'] = '[[softdbpass]]';
$_conf['jrCore_base_url'] = '[[softurl]]';
