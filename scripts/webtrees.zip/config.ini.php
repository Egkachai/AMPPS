; <?php exit; ?> DO NOT DELETE THIS LINE
dbhost="[[softdbhost]]"
dbport="3306"
dbuser="[[softdbuser]]"
dbpass="[[softdbpass]]"
dbname="[[softdb]]"
tblpfx="[[dbprefix]]"
