<?php
 class DB extends DBmysql {
                
 var $dbhost = '[[softdbhost]]';
                
 var $dbuser 	= '[[softdbuser]]';
                
 var $dbpassword= '[[softdbpass]]';
                
 var $dbdefault	= '[[softdb]]';
                
 } 
?>