<?php

/**
 * -----------------------------------------------------------------------------
 * Generated [[Generated_time]]
 *
 * @item      misc.seen_introduction
 * @group     concrete
 * @namespace null
 * -----------------------------------------------------------------------------
 */
return array(
    'site' => '[[site_name]]',
    'locale' => '[[language]]',	
    'version_installed' => '5.7.2',
    'misc' => array(
        'access_entity_updated' => [[timestamp]],
        'latest_version' => '5.6.3.1'
    ),
    'i18n' => array(

        'choose_language_login' => null
    )
);
