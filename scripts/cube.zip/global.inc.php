<?php
$glob['adminFile'] = 'admin.php';
$glob['adminFolder'] = 'admin';
$glob['dbdatabase'] = '[[softdb]]';
$glob['dbhost'] = '[[softdbhost]]';
$glob['dbpassword'] = '[[softdbpass]]';
$glob['dbprefix'] = '[[dbprefix]]';
$glob['dbusername'] = '[[softdbuser]]';
$glob['installed'] = '1';
$glob['install_source'] = 'softaculous';
?>