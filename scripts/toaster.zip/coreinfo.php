<?php
define ('CORE', '[[softpath]]/seotoaster_core/');
define ('SITE_NAME', '[[sn]]');
