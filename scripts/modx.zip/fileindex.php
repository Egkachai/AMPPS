config.core.php
connectors
core
ht.access
index.php
manager
setup
assets