<?php
// lock:0
// inc:2-----------------------------
// row_count:1-----------------------------
// --- start headers ---
// table:user
// columns:1:id:int:0|2:password:string:0|3:active:bool:0|4:name:string:0|5:email_address:string:0|6:last_logged_in:int:1|7:access_level:int:0|8:last_accessed:int:1|9:failed_attempts:int:1|10:lock_until:int:1|11:ip_address:string:1|12:activate_token:string:1|13:reminder_token:string:1|14:reminder_time:int:1
// ---
// ---
// --- end headers ---
// row:1`1`|2`[[admin_pass]]`|3`1`|4`razorCMS`|5`[[admin_email]]`|6`1413178737`|7`10`|8`1413178737`|9`0`|10`1394102525`|11`[[clientip]]`|12``|13``|14`1401710420`