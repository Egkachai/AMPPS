<?php

$db_type = 'mysqli_innodb';
$db_host = '[[softdbhost]]';
$db_name = '[[softdb]]';
$db_username = '[[softdbuser]]';
$db_password = '[[softdbpass]]';
$db_prefix = '[[dbprefix]]';
$p_connect = false;

$cookie_name = '[[cookie_name]]';
$cookie_domain = '';
$cookie_path = '/';
$cookie_secure = 0;
$cookie_seed = '[[cookie_seed]]';

define('PUN', 1);
