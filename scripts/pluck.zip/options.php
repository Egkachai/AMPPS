<?php
$sitetitle = '[[site_name]]';
$email = '[[admin_email]]';
?>