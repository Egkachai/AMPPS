<?php
$title = 'Home';
$content = '<p>This is a sample page.</p>';
$hidden = 'no';
?>