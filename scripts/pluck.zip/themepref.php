<?php
$themepref = 'default';
?>