<?php
$ww = '[[admin_pass]]';
?>