<?php
$langpref = '[[language]].php';
?>