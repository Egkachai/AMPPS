<?php
$appName = '[[site_name]]';
$email = '[[admin_email]]';
$host = '[[softdbhost]]';
$user = '[[softdbuser]]';
$pass = '[[softdbpass]]';
$dbname = '[[softdb]]';
$version = '4.3';
$buildDate = 1412903515;
$updaterVersion = '4.2';
$language='en';
?>