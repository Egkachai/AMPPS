<?php
$db = array(
    'driver' => "pdo",
    'type' => "mysql",
    'host' => "[[softdbhost]]",
    'username' => "[[softdbuser]]",
    'password' => "[[softdbpass]]",
    'database' => "[[softdb]]",
    'prefix' => "[[dbprefix]]",
);