<?php
// Coppermine configuration file
// MySQL configuration
$CONFIG['dbserver'] =                         '[[softdbhost]]';        // Your database server
$CONFIG['dbuser'] =                         '[[softdbuser]]';        // Your mysql username
$CONFIG['dbpass'] =                         '[[softdbpass]]';                // Your mysql password
$CONFIG['dbname'] =                         '[[softdb]]';        // Your mysql database name


// MySQL TABLE NAMES PREFIX
$CONFIG['TABLE_PREFIX'] =                '[[dbprefix]]';
?>